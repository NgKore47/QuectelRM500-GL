# Willing to get introduced to the source code? :)

Just read the [QCSuper architecture.md](../../docs/QCSuper%20architecture.md) document to get a quick glimpse about it.

This directory contain constants and functions related to various protocols and formats (Diag, PCAP, GSMTAP)...

Altogether, these constants and functions are used with the main building blocks for QCSuper, called [modules](../modules).
