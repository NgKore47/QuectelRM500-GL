This directory contains compiled binaries of certain tools which are used when the user lacks these on their machine; namely, `adb`.

Putting compiled binaries here is meant to ease the installation process.

Using `./update_tools.sh` will update `adb` to the latest version.
