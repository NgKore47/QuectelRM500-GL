#!/usr/bin/env python3
#-*- encoding: Utf-8 -*-

from src.main import main

main()
